package com.example.CategoryProduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
